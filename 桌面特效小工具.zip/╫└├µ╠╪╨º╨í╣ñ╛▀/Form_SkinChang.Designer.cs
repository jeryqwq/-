﻿namespace 桌面特效小工具
{
    partial class Form_SkinChang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_SkinChang));
            this.skinButton3 = new CCWin.SkinControl.SkinButton();
            this.skinButton4 = new CCWin.SkinControl.SkinButton();
            this.skinButton5 = new CCWin.SkinControl.SkinButton();
            this.skinButton1 = new CCWin.SkinControl.SkinButton();
            this.skinButton2 = new CCWin.SkinControl.SkinButton();
            this.skinButton6 = new CCWin.SkinControl.SkinButton();
            this.skinButton7 = new CCWin.SkinControl.SkinButton();
            this.skinButton8 = new CCWin.SkinControl.SkinButton();
            this.skinButton9 = new CCWin.SkinControl.SkinButton();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_skin = new CCWin.SkinControl.SkinButton();
            this.SuspendLayout();
            // 
            // skinButton3
            // 
            this.skinButton3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.skinButton3.BackColor = System.Drawing.Color.Transparent;
            this.skinButton3.BaseColor = System.Drawing.Color.Transparent;
            this.skinButton3.BorderColor = System.Drawing.Color.Transparent;
            this.skinButton3.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.skinButton3.DownBack = ((System.Drawing.Image)(resources.GetObject("skinButton3.DownBack")));
            this.skinButton3.DownBaseColor = System.Drawing.Color.Transparent;
            this.skinButton3.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.skinButton3.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinButton3.ForeColor = System.Drawing.Color.White;
            this.skinButton3.GlowColor = System.Drawing.Color.Transparent;
            this.skinButton3.InnerBorderColor = System.Drawing.Color.Transparent;
            this.skinButton3.Location = new System.Drawing.Point(177, 5);
            this.skinButton3.MouseBack = ((System.Drawing.Image)(resources.GetObject("skinButton3.MouseBack")));
            this.skinButton3.MouseBaseColor = System.Drawing.Color.Transparent;
            this.skinButton3.Name = "skinButton3";
            this.skinButton3.NormlBack = ((System.Drawing.Image)(resources.GetObject("skinButton3.NormlBack")));
            this.skinButton3.Size = new System.Drawing.Size(84, 52);
            this.skinButton3.TabIndex = 10;
            this.skinButton3.UseVisualStyleBackColor = false;
            this.skinButton3.Click += new System.EventHandler(this.skinButton3_Click);
            // 
            // skinButton4
            // 
            this.skinButton4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.skinButton4.BackColor = System.Drawing.Color.Transparent;
            this.skinButton4.BaseColor = System.Drawing.Color.Transparent;
            this.skinButton4.BorderColor = System.Drawing.Color.Transparent;
            this.skinButton4.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.skinButton4.DownBack = ((System.Drawing.Image)(resources.GetObject("skinButton4.DownBack")));
            this.skinButton4.DownBaseColor = System.Drawing.Color.Transparent;
            this.skinButton4.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.skinButton4.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinButton4.ForeColor = System.Drawing.Color.White;
            this.skinButton4.GlowColor = System.Drawing.Color.Transparent;
            this.skinButton4.InnerBorderColor = System.Drawing.Color.Transparent;
            this.skinButton4.Location = new System.Drawing.Point(91, 5);
            this.skinButton4.MouseBack = ((System.Drawing.Image)(resources.GetObject("skinButton4.MouseBack")));
            this.skinButton4.MouseBaseColor = System.Drawing.Color.Transparent;
            this.skinButton4.Name = "skinButton4";
            this.skinButton4.NormlBack = ((System.Drawing.Image)(resources.GetObject("skinButton4.NormlBack")));
            this.skinButton4.Size = new System.Drawing.Size(84, 52);
            this.skinButton4.TabIndex = 9;
            this.skinButton4.UseVisualStyleBackColor = false;
            this.skinButton4.Click += new System.EventHandler(this.skinButton4_Click);
            // 
            // skinButton5
            // 
            this.skinButton5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.skinButton5.BackColor = System.Drawing.Color.Transparent;
            this.skinButton5.BaseColor = System.Drawing.Color.Transparent;
            this.skinButton5.BorderColor = System.Drawing.Color.Transparent;
            this.skinButton5.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.skinButton5.DownBack = ((System.Drawing.Image)(resources.GetObject("skinButton5.DownBack")));
            this.skinButton5.DownBaseColor = System.Drawing.Color.Transparent;
            this.skinButton5.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.skinButton5.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinButton5.ForeColor = System.Drawing.Color.White;
            this.skinButton5.GlowColor = System.Drawing.Color.Transparent;
            this.skinButton5.InnerBorderColor = System.Drawing.Color.Transparent;
            this.skinButton5.Location = new System.Drawing.Point(5, 5);
            this.skinButton5.MouseBack = ((System.Drawing.Image)(resources.GetObject("skinButton5.MouseBack")));
            this.skinButton5.MouseBaseColor = System.Drawing.Color.Transparent;
            this.skinButton5.Name = "skinButton5";
            this.skinButton5.NormlBack = ((System.Drawing.Image)(resources.GetObject("skinButton5.NormlBack")));
            this.skinButton5.Size = new System.Drawing.Size(84, 52);
            this.skinButton5.TabIndex = 8;
            this.skinButton5.UseVisualStyleBackColor = false;
            this.skinButton5.Click += new System.EventHandler(this.skinButton5_Click);
            // 
            // skinButton1
            // 
            this.skinButton1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.skinButton1.BackColor = System.Drawing.Color.Transparent;
            this.skinButton1.BaseColor = System.Drawing.Color.Transparent;
            this.skinButton1.BorderColor = System.Drawing.Color.Transparent;
            this.skinButton1.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.skinButton1.DownBack = ((System.Drawing.Image)(resources.GetObject("skinButton1.DownBack")));
            this.skinButton1.DownBaseColor = System.Drawing.Color.Transparent;
            this.skinButton1.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.skinButton1.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinButton1.ForeColor = System.Drawing.Color.White;
            this.skinButton1.GlowColor = System.Drawing.Color.Transparent;
            this.skinButton1.InnerBorderColor = System.Drawing.Color.Transparent;
            this.skinButton1.Location = new System.Drawing.Point(177, 59);
            this.skinButton1.MouseBack = ((System.Drawing.Image)(resources.GetObject("skinButton1.MouseBack")));
            this.skinButton1.MouseBaseColor = System.Drawing.Color.Transparent;
            this.skinButton1.Name = "skinButton1";
            this.skinButton1.NormlBack = ((System.Drawing.Image)(resources.GetObject("skinButton1.NormlBack")));
            this.skinButton1.Size = new System.Drawing.Size(84, 52);
            this.skinButton1.TabIndex = 13;
            this.skinButton1.UseVisualStyleBackColor = false;
            this.skinButton1.Click += new System.EventHandler(this.skinButton1_Click);
            // 
            // skinButton2
            // 
            this.skinButton2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.skinButton2.BackColor = System.Drawing.Color.Transparent;
            this.skinButton2.BaseColor = System.Drawing.Color.Transparent;
            this.skinButton2.BorderColor = System.Drawing.Color.Transparent;
            this.skinButton2.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.skinButton2.DownBack = ((System.Drawing.Image)(resources.GetObject("skinButton2.DownBack")));
            this.skinButton2.DownBaseColor = System.Drawing.Color.Transparent;
            this.skinButton2.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.skinButton2.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinButton2.ForeColor = System.Drawing.Color.White;
            this.skinButton2.GlowColor = System.Drawing.Color.Transparent;
            this.skinButton2.InnerBorderColor = System.Drawing.Color.Transparent;
            this.skinButton2.Location = new System.Drawing.Point(91, 59);
            this.skinButton2.MouseBack = ((System.Drawing.Image)(resources.GetObject("skinButton2.MouseBack")));
            this.skinButton2.MouseBaseColor = System.Drawing.Color.Transparent;
            this.skinButton2.Name = "skinButton2";
            this.skinButton2.NormlBack = ((System.Drawing.Image)(resources.GetObject("skinButton2.NormlBack")));
            this.skinButton2.Size = new System.Drawing.Size(84, 52);
            this.skinButton2.TabIndex = 12;
            this.skinButton2.UseVisualStyleBackColor = false;
            this.skinButton2.Click += new System.EventHandler(this.skinButton2_Click);
            // 
            // skinButton6
            // 
            this.skinButton6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.skinButton6.BackColor = System.Drawing.Color.Transparent;
            this.skinButton6.BaseColor = System.Drawing.Color.Transparent;
            this.skinButton6.BorderColor = System.Drawing.Color.Transparent;
            this.skinButton6.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.skinButton6.DownBack = ((System.Drawing.Image)(resources.GetObject("skinButton6.DownBack")));
            this.skinButton6.DownBaseColor = System.Drawing.Color.Transparent;
            this.skinButton6.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.skinButton6.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinButton6.ForeColor = System.Drawing.Color.White;
            this.skinButton6.GlowColor = System.Drawing.Color.Transparent;
            this.skinButton6.InnerBorderColor = System.Drawing.Color.Transparent;
            this.skinButton6.Location = new System.Drawing.Point(5, 59);
            this.skinButton6.MouseBack = ((System.Drawing.Image)(resources.GetObject("skinButton6.MouseBack")));
            this.skinButton6.MouseBaseColor = System.Drawing.Color.Transparent;
            this.skinButton6.Name = "skinButton6";
            this.skinButton6.NormlBack = ((System.Drawing.Image)(resources.GetObject("skinButton6.NormlBack")));
            this.skinButton6.Size = new System.Drawing.Size(84, 52);
            this.skinButton6.TabIndex = 11;
            this.skinButton6.UseVisualStyleBackColor = false;
            this.skinButton6.Click += new System.EventHandler(this.skinButton6_Click);
            // 
            // skinButton7
            // 
            this.skinButton7.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.skinButton7.BackColor = System.Drawing.Color.Transparent;
            this.skinButton7.BaseColor = System.Drawing.Color.Transparent;
            this.skinButton7.BorderColor = System.Drawing.Color.Transparent;
            this.skinButton7.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.skinButton7.DownBack = ((System.Drawing.Image)(resources.GetObject("skinButton7.DownBack")));
            this.skinButton7.DownBaseColor = System.Drawing.Color.Transparent;
            this.skinButton7.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.skinButton7.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinButton7.ForeColor = System.Drawing.Color.White;
            this.skinButton7.GlowColor = System.Drawing.Color.Transparent;
            this.skinButton7.InnerBorderColor = System.Drawing.Color.Transparent;
            this.skinButton7.Location = new System.Drawing.Point(177, 113);
            this.skinButton7.MouseBack = ((System.Drawing.Image)(resources.GetObject("skinButton7.MouseBack")));
            this.skinButton7.MouseBaseColor = System.Drawing.Color.Transparent;
            this.skinButton7.Name = "skinButton7";
            this.skinButton7.NormlBack = ((System.Drawing.Image)(resources.GetObject("skinButton7.NormlBack")));
            this.skinButton7.Size = new System.Drawing.Size(84, 52);
            this.skinButton7.TabIndex = 16;
            this.skinButton7.UseVisualStyleBackColor = false;
            this.skinButton7.Click += new System.EventHandler(this.skinButton7_Click);
            // 
            // skinButton8
            // 
            this.skinButton8.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.skinButton8.BackColor = System.Drawing.Color.Transparent;
            this.skinButton8.BaseColor = System.Drawing.Color.Transparent;
            this.skinButton8.BorderColor = System.Drawing.Color.Transparent;
            this.skinButton8.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.skinButton8.DownBack = ((System.Drawing.Image)(resources.GetObject("skinButton8.DownBack")));
            this.skinButton8.DownBaseColor = System.Drawing.Color.Transparent;
            this.skinButton8.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.skinButton8.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinButton8.ForeColor = System.Drawing.Color.White;
            this.skinButton8.GlowColor = System.Drawing.Color.Transparent;
            this.skinButton8.InnerBorderColor = System.Drawing.Color.Transparent;
            this.skinButton8.Location = new System.Drawing.Point(91, 113);
            this.skinButton8.MouseBack = ((System.Drawing.Image)(resources.GetObject("skinButton8.MouseBack")));
            this.skinButton8.MouseBaseColor = System.Drawing.Color.Transparent;
            this.skinButton8.Name = "skinButton8";
            this.skinButton8.NormlBack = ((System.Drawing.Image)(resources.GetObject("skinButton8.NormlBack")));
            this.skinButton8.Size = new System.Drawing.Size(84, 52);
            this.skinButton8.TabIndex = 15;
            this.skinButton8.UseVisualStyleBackColor = false;
            this.skinButton8.Click += new System.EventHandler(this.skinButton8_Click);
            // 
            // skinButton9
            // 
            this.skinButton9.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.skinButton9.BackColor = System.Drawing.Color.Transparent;
            this.skinButton9.BaseColor = System.Drawing.Color.Transparent;
            this.skinButton9.BorderColor = System.Drawing.Color.Transparent;
            this.skinButton9.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.skinButton9.DownBack = ((System.Drawing.Image)(resources.GetObject("skinButton9.DownBack")));
            this.skinButton9.DownBaseColor = System.Drawing.Color.Transparent;
            this.skinButton9.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.skinButton9.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinButton9.ForeColor = System.Drawing.Color.White;
            this.skinButton9.GlowColor = System.Drawing.Color.Transparent;
            this.skinButton9.InnerBorderColor = System.Drawing.Color.Transparent;
            this.skinButton9.Location = new System.Drawing.Point(5, 113);
            this.skinButton9.MouseBack = ((System.Drawing.Image)(resources.GetObject("skinButton9.MouseBack")));
            this.skinButton9.MouseBaseColor = System.Drawing.Color.Transparent;
            this.skinButton9.Name = "skinButton9";
            this.skinButton9.NormlBack = ((System.Drawing.Image)(resources.GetObject("skinButton9.NormlBack")));
            this.skinButton9.Size = new System.Drawing.Size(84, 52);
            this.skinButton9.TabIndex = 14;
            this.skinButton9.UseVisualStyleBackColor = false;
            this.skinButton9.Click += new System.EventHandler(this.skinButton9_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(122, 175);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 14);
            this.label1.TabIndex = 17;
            this.label1.Text = "自定义";
            // 
            // btn_skin
            // 
            this.btn_skin.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btn_skin.BackColor = System.Drawing.Color.Transparent;
            this.btn_skin.BaseColor = System.Drawing.Color.Transparent;
            this.btn_skin.BorderColor = System.Drawing.Color.Transparent;
            this.btn_skin.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btn_skin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_skin.DownBack = ((System.Drawing.Image)(resources.GetObject("btn_skin.DownBack")));
            this.btn_skin.DownBaseColor = System.Drawing.Color.Transparent;
            this.btn_skin.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btn_skin.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_skin.ForeColor = System.Drawing.Color.White;
            this.btn_skin.GlowColor = System.Drawing.Color.Transparent;
            this.btn_skin.InnerBorderColor = System.Drawing.Color.Transparent;
            this.btn_skin.Location = new System.Drawing.Point(96, 172);
            this.btn_skin.MouseBack = ((System.Drawing.Image)(resources.GetObject("btn_skin.MouseBack")));
            this.btn_skin.MouseBaseColor = System.Drawing.Color.Transparent;
            this.btn_skin.Name = "btn_skin";
            this.btn_skin.NormlBack = ((System.Drawing.Image)(resources.GetObject("btn_skin.NormlBack")));
            this.btn_skin.Size = new System.Drawing.Size(23, 19);
            this.btn_skin.TabIndex = 18;
            this.btn_skin.UseVisualStyleBackColor = false;
            this.btn_skin.Click += new System.EventHandler(this.btn_skin_Click);
            // 
            // Form_SkinChang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.CaptionHeight = 4;
            this.ClientSize = new System.Drawing.Size(267, 197);
            this.ControlBox = false;
            this.Controls.Add(this.btn_skin);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.skinButton7);
            this.Controls.Add(this.skinButton8);
            this.Controls.Add(this.skinButton9);
            this.Controls.Add(this.skinButton1);
            this.Controls.Add(this.skinButton2);
            this.Controls.Add(this.skinButton6);
            this.Controls.Add(this.skinButton3);
            this.Controls.Add(this.skinButton4);
            this.Controls.Add(this.skinButton5);
            this.EffectBack = System.Drawing.Color.Transparent;
            this.Name = "Form_SkinChang";
            this.ShowDrawIcon = false;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "";
            this.TopMost = true;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CCWin.SkinControl.SkinButton skinButton3;
        private CCWin.SkinControl.SkinButton skinButton4;
        private CCWin.SkinControl.SkinButton skinButton5;
        private CCWin.SkinControl.SkinButton skinButton1;
        private CCWin.SkinControl.SkinButton skinButton2;
        private CCWin.SkinControl.SkinButton skinButton6;
        private CCWin.SkinControl.SkinButton skinButton7;
        private CCWin.SkinControl.SkinButton skinButton8;
        private CCWin.SkinControl.SkinButton skinButton9;
        private System.Windows.Forms.Label label1;
        private CCWin.SkinControl.SkinButton btn_skin;
    }
}